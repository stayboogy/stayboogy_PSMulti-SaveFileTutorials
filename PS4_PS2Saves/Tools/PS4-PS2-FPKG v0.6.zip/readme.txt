PS2-FPKG v0.6 by Jabu

This app converts PS2 ISO/BIN games to fPKG which can be installed directly on PS4.​

How to use:
1. Run ps2-fpkg.exe
2. Select the ISO of the PS2 game in "Disc1"
3. Click "Create fPKG" and choose a storage location
4. Install the created fPKG on your PS4 and play

Note: For CD games (.bin) click YES when asked about adding LIMG sector.


Optionally you can:
-change the game icon (Icon),
-change background graphic when starting the game (Bg),
-create a multi-disc game (up to 5 iso)
-add your own config txt,
-add your own config lua,
-select the emulator to be used by the game (by default there are 2 known to be most compatible, you can add more)
-import a custom 8MB memory card (.ps2, .vm2, .bin [OPL VMC])
-change PS Vita remote play key bindings
-customize the lightbar colors
-use FastForward(works best on loading screens)


Program automatically adds configs (config-emu-ps4.txt), ps3 (gameid_lopnor.cfgbin), lua (gameid_config.lua) if they exist in application database.
Yes, this application comes with unique ready to go PS2 game configs and widescreen patches that will be added automatically!


How to enable Widescreen Patches:
Check the "Widescreen Patches" checkbox in the "Graphics Settings" tab. 
It's not enabled by default because it needs some more testing. This setting will be saved.
If the app finds a widescreen patch for your game, it will be automatically used. 

How to add more emulators:
Put the folder with emulator files into the "emus" folder, restart ps2-fpkg,
new emulators should show up on the list, that's all.


Known issues/bugs:
-Few games do not follow SYSTEM.CNF's standard layout, for these games the app will fail to find the game ID (partially fixed, only CD games affected now)
-If the program has any problems with creating fPKGs, you can try to run it as an administrator, it should help.
-App will fail to create pkgs if the path to save pkg is root of drive, like C:\ E:\. Fix it by creating pkg to for example E:\pkg
-Memory cards greater than 8MB won't work. This is a emulator limitation, not app itself.
-crc.exe may be detected by some lame anti-viruses as malware, THIS IS A FALSE POSITIVE!
-Widescreen Patches won't work with CD(in .bin format) games

--------------------------------------------------------------------------------------------------------------
CHANGELOG:

v0.6
-Command line window is now hidden, animated "Creating PKG" text on the status bar is now shown instead
-The main window won't freeze anymore while creating a PKG (pkg creation process was moved to different thread)
-PKG creation errors will now show up in a window
-Added settings for uprender, upscale, and display mode in the new "Graphics Settings" tab"
-Added a FastForward option, this allows you to set a custom combo to remove the framelimiter, and for example speed up loading screens or FMVs, or even gameplay sometimes.
-FastForward option is available in 2 modes. Hold the combo to fastforward or press a combo to toggle it on/off.
-Added a option to change the DS4 Lightbar color for normal gameplay and for fast forward mode. 
-Added game elf CRC reading to allow imported widescreen patches to be found by the app(via crc.exe)
-Added auto widescreen patches (3700 patches fetched from pcsx2 repository)
-"Try to fix graphics" is now enabled by default
-Some GUI changes
-More broken english

v0.5
-Added OPL's Virtual Memory Card (.bin) support
-You can now select a Keymap layout for Vita Remoteplay
-Fixed some code, again

v0.4 
-Custom Memory Card support! You can now import a 8MB .vm2/.ps2 memory card's from a ps3 or pcsx2, it should work in all games.
-The gui is now using tabs
-JPG/BMP support added
-Removed "try to improve compatibility"
-Added "Try to improve Speed", should fix games like GOW 1 and 2, may break some others(this may not work on some emulators)
-Added "Try to fix Graphics", fixes AirBlade, Frogger: Ancient Shadow, God Hand, SpongeBob SquarePants: Battle for Bikini Bottom and maybe others.
-Fixed some code

v0.3
-Added compression support
-Added PS2 CD .bin support(app wil auto-add LIMG sector)
-Fixed game ID searching code, it's fast now 

v0.2  
-Initial release


--------------------------------------------------------------------------------------------------------------
Files used:
-TXT and LUA Configs - https://github.com/kozarovv/PS2-Configs
-PS3 Configs- https://github.com/Zarh/ManaGunZ/tree/master/pkgfiles/USRDIR/sys/CONFIG
-List of PS2 Game IDs - https://github.com/Veritas83/PS2-OPL-CFG/blob/master/test/PS2-GAMEID-TITLE-MASTER.csv
-PCSX2's WS Patches Converted by Kozarov

Programs used:
-Image Magic - https://imagemagick.org/
-7-Zip - https://7-zip.org/
-DiscUtils - https://github.com/DiscUtils/DiscUtils
-ecc_check
-crc.py(I converted it into a exe) https://gist.github.com/asahui/a6af64606a9476a40442274335f5feaf

Credits:
Thanks Kozarovv for help and suggestions. @Zar for his ps3 configs database. Veritas83 (@VTSTech ) for PS2 GAMEID TITLE database.
